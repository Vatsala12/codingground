#!/bin/sh
NAME="vatsala"
echo $NAME 
