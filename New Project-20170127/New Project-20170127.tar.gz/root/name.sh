echo "what is your name?"
read PERSON
echo "Hello, $PERSON"