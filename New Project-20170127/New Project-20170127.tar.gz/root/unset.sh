#!/bin/sh
NAME="vts"
unset NAME
echo $NAME