#!/bin/sh
echo "File Name: $0"
echo "first parameter : $1"
echo "second parameter : $2"
echo "quoted values :$@ "
echo "quoted values  : $*"
echo "total number of parameters  : $#"