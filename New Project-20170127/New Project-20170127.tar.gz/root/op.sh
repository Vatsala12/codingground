#!/bin/sh
val=`expr 3 + 2`
echo "Total value : $val"
