#!/bin/sh
for TOKEN in $*
do
echo $TOKEN
done