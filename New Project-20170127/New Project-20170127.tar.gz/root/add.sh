#!/bin/sh
echo "enter value 1"
read VAL1
echo "enter value 2"
read VAL2
echo "addition of val1 val2"
VAL3=`expr $VAL1 % $VAL2`
echo "total: $VAL3"